# -*- coding: utf-8 -*-
from sys import argv
from modules.router import routing
routing(argv[2])
